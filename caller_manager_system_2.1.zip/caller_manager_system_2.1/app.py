#!/bin/python3 

import requests
from flask import Flask, jsonify, request, render_template, redirect, url_for
import pymysql

vos_api = "http://127.0.0.1:6365/external/server/"                     #vos的web api

def get_db():
    return pymysql.connect(
        host="localhost",
        user="root",
        password="",
        database="vos3000",
        autocommit=True
    )



app = Flask(__name__)


@app.route("/api/gatewaymapping")                                #对接网关
def show_gatewaymapping():
	gateways = []
	numbers = []
	json_data={}
	conn = get_db()
	cursor = conn.cursor()                                   #执行sql语句
	res = requests.post(url=vos_api+'GetGatewayMapping',json = json_data)
	datas = res.json()
	for i in datas['infoGatewayMappings']:
		#print(i['name'])
		if i['rewriteRulesOutCaller'] != ''and i['lockType'] == 0 :
			a = i['rewriteRulesOutCaller'].split(':', 1)[1].split(';') 
			gateways.append({'name':i['name'],'caller':a})
			numbers.extend(a)
		if i['calloutCallerPrefixes'] != '' and i['lockType'] == 0:
			a = i['calloutCallerPrefixes'].split(',')
			gateways.append({'name':i['name'],'caller':a})
			numbers.extend(a) 

	if not numbers:
		cursor.close()
		conn.close()
		return render_template("gateways.html", flag = 'mapping',gateways=gateways)
	
	placeholders = ",".join(["%s"] * len(numbers))
	sql = f"""
		select caller, valid_count, used_count
		from numbers_info
		where caller in ({placeholders})
		"""
	cursor.execute(sql, numbers)
	rows = cursor.fetchall()

	stats = {row[0]: {'valid': row[1], 'used': row[2]} for row in rows}
	for g in gateways:
		g['avg_answer_rate'] = 0
		g['stats'] = []                                        #这里网关g需要加一个平均值接通率的值
		for c in g['caller']:
			if c not in stats or stats[c]['used'] == 0:
				g['stats'].append({'number':c, 'used':0, 'answer_rate': 0, 'type' : 'ModifyGatewayMapping', 'gateway_name':g['name']})
			else:
				g['stats'].append({'number':c, 'used': stats[c]['used'], 'answer_rate':stats[c]['valid']/stats[c]['used'],'type' : 'ModifyGatewayMapping', 'gateway_name':g['name']})
				g['avg_answer_rate'] = g['avg_answer_rate'] + stats[c]['valid']/stats[c]['used']
				g['avg_answer_rate'] = g['avg_answer_rate']/len(g['caller'])

	
	cursor.close()
	conn.close()
	return render_template("gateways.html", flag = 'mapping',gateways=gateways)

@app.route("/api/gatewayrouting",methods=['GET'])                                #落地网关
def show_gatewayrouting():
	numbers = []
	gateways = []
	json_data={}
	conn = get_db()
	cursor = conn.cursor()
	res = requests.post(url=vos_api+'GetGatewayRouting',json = json_data)
	datas = res.json()
	for i in datas['infoGatewayRoutings']:
		if i['rewriteRulesInCaller'] != '' and i['lockType'] == 0 and '测试' not in i['name'] and '黑名单' not in i['name']:
			a = i['rewriteRulesInCaller'].split(':', 1)[1].split(';') 
			gateways.append({'name':i['name'],'caller':a})
			numbers.extend(a)
	if not numbers:
		cursor.close()
		conn.close()
		return render_template("gateways.html", flag = 'mapping',gateways=gateways)

	placeholders = ",".join(["%s"] * len(numbers))
	sql = f"""
		select caller, valid_count, used_count
		from numbers_info
		where caller in ({placeholders})
		"""
	cursor.execute(sql, numbers)
	rows = cursor.fetchall()
	stats = {row[0]: {'valid': row[1], 'used': row[2]} for row in rows}
	for g in gateways:
		g['stats'] = []
		g['avg_answer_rate'] = 0                                     #记录网关的平均应答率
		for c in g['caller']:         #网关的主叫号码
			if c not in stats or stats[c]['used'] == 0:
				g['stats'].append({'number':c, 'used':0, 'answer_rate': 0, 'type' : 'ModifyGatewayRouting', 'gateway_name':g['name']})
			else:
				g['stats'].append({'number':c, 'used': stats[c]['used'], 'answer_rate':stats[c]['valid']/stats[c]['used'], 'type':'ModifyGatewayRouting','gateway_name':g['name']})
				g['avg_answer_rate'] = g['avg_answer_rate'] + stats[c]['valid']/stats[c]['used']
		g['avg_answer_rate'] = g['avg_answer_rate']/len(g['caller'])
		#print(g['name'] + " 平均应答率是 " +str(g['avg_answer_rate']))

	cursor.close()
	conn.close()
	return render_template("gateways.html",flag = 'routing', gateways=gateways)
	
@app.route("/api/update_caller", methods=['POST'])                                # 更换号码的api
def update_caller():
	data = request.get_json()
	json_data = {}
	if not data:
		return jsonify({'error': 'No JSON data received'}), 400
	caller = data.get('caller')
	if not caller:
		return jsonify({'error': '号码为空'}),200
	gateway = data.get('gateway_name')
	call_type = data.get('type')
	
	numbers = caller.split(',')                   #获取新主叫,拼接改写规则
	rules = '*:'
	for i in numbers:
		rules = rules + i + ';'
	rules = rules[:-1]	
	if call_type == 'ModifyGatewayRouting':
		json_data = {'name': gateway, 'rewriteRulesInCaller':rules}
	elif call_type == 'ModifyGatewayMapping':
		json_data = {'name': gateway, 'rewriteRulesOutCaller':rules}
	res = requests.post(url=vos_api + call_type,json = json_data)
	#print(res.json())


	if call_type == 'ModifyGatewayRouting':
		return jsonify({'success': '更换主叫成功!','type':'gatewayrouting'}), 200
	elif call_type == 'ModifyGatewayMapping':
		return jsonify({'success': '更换主叫成功!','type':'gatewaymapping'}), 200


@app.route("/api/reset", methods=['POST'])                                # 更换号码的api
def reset():
	data = request.get_json()
	if not data:
		return jsonify({'error': 'No JSON data received'}), 400
	caller = data.get('caller')
	#重置主叫号码的呼叫次数
	sql = f"""
                UPDATE numbers_info 
		SET  valid_count = 0, used_count = 0
		WHERE caller = %s                               
                """
	conn = get_db()
	cursor = conn.cursor()	
	cursor.execute(sql,caller)
	conn.commit()
	cursor.close()
	conn.close()
	return jsonify({'success': caller +' 重置成功'}), 200
	
@app.route("/api/pool")
def show_pool():
	return render_template("pool.html")


@app.route("/")
def index():
	return render_template("test.html")

if __name__ == "__main__":
	app.run(host="0.0.0.0", port=1234, debug=True)


